# Wealthify-AI
A financial website which suggest some ways to save our money
